package clase03_05_23;

public class operaciones_metods {
	int num1;
	int num2;

	public void operaciones() {
	}


	public operaciones_03_05_23(int num1, int num2) {
		this.num1 = num1;
		this.num2 = num2;
	}
	public int getNum1() {
		return num1;
	}
	public void setNum1(int num1) {
		this.num1 = num1;
	}
	public int getNum2() {
		return num2;
	}
	public void setNum2(int num2) {
		this.num2 = num2;
	}
	// metodos u operaciones propios

	public static int Suma(int num1, int num2) {
		int suma;
		suma= num1+num2;
		return suma;
	}
	
	public static int resta(int a,int b) {
		int resta;
		resta= a-b;
		return resta;
	}
	
	 public void Mostrar_mensaje() {
		 System.out.println("Saliendo***");
	 }
	 public void Saltos () {
		 for(int i=0; i<=40; i++);
	 }

       int n;
       int factorial=0;
	public void factorial(int n) {
		for(int i=1; i<=n;i++) {
		factorial= factorial*i;
		}
		
	}
}
