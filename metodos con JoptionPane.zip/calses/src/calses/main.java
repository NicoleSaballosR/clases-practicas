package calses;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int x,y;
		JOptionPane.showMessageDialog(null, "calculamos la multiplicacion");
		
		String num1=JOptionPane.showInputDialog("Ingrese primer numero");
		String num2=JOptionPane.showInputDialog("Ingrese segundo numero");
		
		//conversion
		x=Integer.parseInt(num1);
		y=Integer.parseInt(num2);
		
		propiedades op = new propiedades(x, y);
		//tc.nextLine();
		//System.out.println("resultado"+op.Mult(x, y));
		
		JOptionPane.showMessageDialog(null, "resultado"+op.Mult(x, y));
		
		//int suma= new Integer(num1)+ new Integer (num2);
		
	//	JOptionPane.showInternalMessageDialog(null, "la suma"+suma);
		
		//propiedades po= new propiedades(x, y);
		
		//System.out.println("el resulta;"+po.Mult(x, y));
		//tc.nextLine();
		
	//	tc.nextLine();
		//po.saludar();
		
		
	}

}
