package clase25_04_23;

import java.util.Scanner;

public class practica2 {

	public static void main(String[] args) {
		// //Dado n voltajes imprimir el mayor, menor y promedio 
         Scanner tc= new Scanner(System.in);
         
         int vector [], datos = 0, n;
         int suma = 0;
         float promedio;
         
         System.out.println("Ingrese el tamaño del vector");
         n= tc.nextInt();
         vector= new int [n];
         
         for (int i = 0; i< vector.length; i++) {
        	 System.out.println("Ingrese los datos que desea evaluar"+(i+1));
        	 datos= tc.nextInt();
        	vector[i]= datos;
        	suma += datos;
         }
     
         
 
		int menor, mayor;
		
		 mayor = menor= vector[0];
		
		for (int i=0; i<vector.length; i++) {
			if (vector[i]>mayor) {
				mayor= vector[i];
			}
			if (vector[i]<menor) {
				menor= vector[i];
			}
			 System.out.println("El voltaje mayor es: \n"+mayor);
			 System.out.println("El voltaje menor es: \n"+menor);
			 
			promedio= suma/n;
			System.out.println("El promedio es de: \n"+promedio);
		}
	}

}
