package prcat;

public class operaciones {
	double fact;

	//Constructor
	public operaciones(double fact) {
		super();
		this.fact = fact;
	}
	
	
	//Setter and Getter
	public double getFact() {
		return fact;
	}

	public void setFact(double fact) {
		this.fact = fact;
	}

	
	public static double Factor(double fact) {
		double salida;
		salida=fact*1;
	return salida;
		//return  salida;
	}
	
	
}
