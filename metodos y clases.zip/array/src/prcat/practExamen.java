package prcat;

import java.util.Scanner;

public class practExamen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		String dato="";
		char aux = 0;
		
		 
		for(char i='A'; i<='Z'; i++) {

		dato=Character.toString(areglo1:);
			
					
		}
		
		System.out.println("salida: "+dato);
		
		//System.out.println(dato.toLowerCase()+ " "+ dato.toUpperCase());
		
		//System.out.println(dato.charAt(22));
	}

	 
}
