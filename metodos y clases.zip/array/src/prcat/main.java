package prcat;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {

//		char dato='c';
		//  String aux;
		  
		 // String aux= dato +"";
		//aux=  String.valueOf(dato);
		
		
		//  System.out.println("de vuelto a String "+aux);
		   
	Scanner tc= new Scanner(System.in);
	
	double x;
	System.out.println("Ingrese un numero a factoriar!!");
	x=tc.nextDouble();
	operaciones op= new operaciones(x);
			
	System.out.println("el resultado"+op.fact);
	
	
	}

}
