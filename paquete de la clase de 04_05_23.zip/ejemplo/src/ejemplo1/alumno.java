package ejemplo1;

import javax.swing.JOptionPane;

public class alumno extends persona{
	 
	
	
	private String matricula;
	

	public alumno(String nombre, String apellido, String acionalidad, String matricula) {
		super(nombre, apellido, acionalidad);
		this.matricula = matricula;
	}


	public String getMatricula() {
		return matricula;
	}


	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}


	public alumno(String nombre, String apellido, String acionalidad) {
		super(nombre, apellido, acionalidad);
		// TODO Auto-generated constructor stub
	}
    public void mostrar() {
	JOptionPane.showMessageDialog(null, "Alumno"+"\n" + getNombre()+""+"\n"+getApellido()+""+"\n"+ getMatricula()+"\n "+"Nacionalidad"+ "\n"+getAcionalidad());
	
}
	
}
