package ejemplo1;

public class persona {
   private String nombre;
   private String apellido;
   private String nacionalidad;
public String getNombre() {
	return nombre;
}
public void setNombre(String nombre) {
	this.nombre = nombre;
}
public String getApellido() {
	return apellido;
}
public void setApellido(String apellido) {
	this.apellido = apellido;
}
public String getAcionalidad() {
	return nacionalidad;
}
public void setAcionalidad(String acionalidad) {
	this.nacionalidad = acionalidad;
}
public persona(String nombre, String apellido, String acionalidad) {
	super();
	this.nombre = nombre;
	this.apellido = apellido;
	this.nacionalidad = acionalidad;
}
   
   
}


