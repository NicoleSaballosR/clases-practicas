package ejemplo1;

public class herencia_main {

	public static void main(String[] args) {
	
		alumno al= new alumno("JUAN", "Robles", "CR");
		al.setMatricula("12345");
		al.mostrar();
	}

}
