package ejemplo1;

public class profesor extends persona{

	 private String cedula;
	
	
	public String getCedula() {
		return cedula;
	}



	public void setCedula(String cedula) {
		this.cedula = cedula;
	}



	public profesor(String nombre, String apellido, String acionalidad) {
		super(nombre, apellido, acionalidad);
		// TODO Auto-generated constructor stub
	}
}
