package clase27_04_23;

import java.util.Scanner;

public class ejercicio3 {

	public static void main(String[] args) {
		// 3 enteros ordenarlos de menor a mayor 

		Scanner tc= new Scanner(System.in);
		int array[], auxi, min;
		array= new int[3];
		
		for (int i=0; i<3;i++) {
		System.out.println("Ingrese 3 numeros enteros"+(i+1));
		array[i]=tc.nextInt();
		}
		for (int u=0;u<array.length-1; u++) {
			min=u;
			for ( int d=u+1; d<array.length;d++) {
				if (array[d]<array[min]) {
					min=d;
				}
			}
			auxi= array[u];
			array[u]= array[min];
			array[min]=auxi;
		}
		System.out.println("");
	}

}
