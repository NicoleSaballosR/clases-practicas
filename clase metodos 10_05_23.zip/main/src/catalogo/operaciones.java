package catalogo;

public class operaciones {
 float a, b;
float potencia=0, mult=0, factorial=0;
float raizC=0, raizCU=0,divi=0 ; 


 public operaciones(float a, float b, float potencia, float mult, float factorial, float raizC, float raizCU,
		float divi) {
	super();
	this.a = a;
	this.b = b;
	this.potencia = potencia;
	this.mult = mult;
	this.factorial = factorial;
	this.raizC = raizC;
	this.raizCU = raizCU;
	this.divi = divi;
}
public float getA() {
	return a;
}
public void setA(float a) {
	this.a = a;
}
public float getB() {
	return b;
}
public void setB(float b) {
	this.b = b;
}
public float getPotencia() {
	return potencia;
}
public void setPotencia(float potencia) {
	this.potencia = potencia;
}
public float getMult() {
	return mult;
}
public void setMult(float mult) {
	this.mult = mult;
}
public float getFactorial() {
	return factorial;
}
public void setFactorial(float factorial) {
	this.factorial = factorial;
}
public float getRaizC() {
	return raizC;
}
public void setRaizC(float raizC) {
	this.raizC = raizC;
}
public float getRaizCU() {
	return raizCU;
}
public void setRaizCU(float raizCU) {
	this.raizCU = raizCU;
}

 
}
