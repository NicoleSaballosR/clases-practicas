package catalogo;

public class opc1 extends operaciones {

	public opc1(float a, float b, float potencia, float mult, float factorial, float raizC, float raizCU, float divi) {
		super(a, b, potencia, mult, factorial, raizC, raizCU, divi);
		// TODO Auto-generated constructor stub	
}
	public float potencia(float a, float b) {
		potencia= (int) Math.pow(a, b);
		return potencia;
		
	}
	  public float  mult(float a, float b) {
		  mult= a*b;
		  return mult;
	  }
	  public float divi(float a, float b) {
		  divi= a/b;
		  return divi;
	  
}
}