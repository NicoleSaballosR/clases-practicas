package catalogo;

import java.util.Scanner;

public class menu_opcion {

	public static void main(String[] args) {
		//  
		
      Scanner tc= new Scanner(System.in);
      int opc;
	System.out.println("ingrese que operación desea realizar");
	System.out.println(" 1-potencia \n 2- división \n 3- factorial \n 4- raizC \n 5- raizCu \n 6- mult \n 7- salida ");
	opc= tc.nextInt();
	do {
		switch (opc) {
	case 1:
		if (opc==1) {
			   System.out.println("Ingrese el primer valor el cual desea potenciar");
			    int a= tc.nextInt();
			    System.out.println("Ingrese el segundo valor, que actuara con potenciador");
			    int b= tc.nextInt();
			    System.out.println("El valor es: " );
		}
		case 2:
			if (opc==2) {
				   System.out.println("Ingrese el primer valor");
				    int a= tc.nextInt();
				    System.out.println("Ingrese el segundo valor");
				    int b= tc.nextInt();
				    System.out.println("El valor es: ");
			}
		case 3:
		if (opc==3) {
			System.out.println("Ingrese el primer valor");
		    int a= tc.nextInt();
		    System.out.println("Ingrese el segundo valor");
		    int b= tc.nextInt();
		    System.out.println("El valor es: ");
		}
		case 4:
			if (opc==4) {
			System.out.println("Ingrese el primer valor");
		    int a= tc.nextInt();
		    System.out.println("Ingrese el segundo valor");
		    int b= tc.nextInt();
		    System.out.println("El valor es: ");
		}
		case 5:
			if (opc==5) {
				System.out.println("Ingrese el primer valor");
			    int a= tc.nextInt();
			    System.out.println("Ingrese el segundo valor");
			    int b= tc.nextInt();
			    System.out.println("El valor es: ");
			}
		case 6:
			if(opc==6) {
				System.out.println("Ingrese el primer valor");
			    int a= tc.nextInt();
			    System.out.println("Ingrese el segundo valor");
			    int b= tc.nextInt();
			    System.out.println("El valor es: ");
			}
		case 7:
			if (opc==7) {
				System.out.println("Salida");
			}
	} 
	
}while (opc==7);
}
}
