package clase25_04_23;
import java.util.Scanner;

public class practica3 {

	public static void main(String[] args) {
		// Validar la edad de una persona si su edad es menor a 10; niño, si es mayor a 10 y menor o igual a 15; adolecente 
		//y si esta en el rango de 16 a 20; joven, de 20 a 30; adulto, 30 a 50; señor 
         
		Scanner tc= new Scanner(System.in);
		
		String nombre;
		int  edad;
		//**********************************************************************************
		
		System.out.println("Ingrese su nombre");
		nombre= tc.nextLine();
		System.out.println("Hola"+ nombre+ "\n ingrese su edad");
		edad= tc.nextInt();
		 
		if (edad<10) {
			System.out.println("Usted es un niñ@");
		}
		else if (edad>10 && edad<=15) {
			System.out.println("Usted es un adolecente");
		}
		else if (edad>16 && edad<=20) {
			System.out.println("Usted es un Joven");
		}
		else if (edad>20 && edad<=30) {
			System.out.println("Usted es un adulto");
		}
		else {
			System.out.println("Usted es un señor");
		}
		
	}
}


