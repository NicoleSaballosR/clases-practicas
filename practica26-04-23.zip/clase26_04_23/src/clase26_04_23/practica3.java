package clase26_04_23;

import java.util.ArrayList;
import java.util.Scanner;

public class practica3 {

	public static void main(String[] args) {
		//clase ArrayList
		
		Scanner tc= new Scanner(System.in);
		int n;
		System.out.println("Ingrese el tamaño del arreglo");
		n= tc.nextInt();
		
		ArrayList<Integer> arrai1= new ArrayList<>(n);
		
		ArrayList<String> frutas= new ArrayList<String>();
		frutas.add("Mango");
		frutas.add("Pera");
		frutas.add("Sandia");
		
		System.out.println(frutas);
		for (int i=1; i<=n; i++) {
			arrai1.add(i);
	
		}
		System.out.println("Array:"+ arrai1+ frutas);
		
		for(int j=0;j<frutas.size(); j++) {
			System.out.println(frutas.get(j));
		}
	}

}
