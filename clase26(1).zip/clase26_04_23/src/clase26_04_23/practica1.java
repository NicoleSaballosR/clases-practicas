package clase26_04_23;

import java.util.Scanner;

public class practica1 {

	public static void main(String[] args) {
		// mostrar números del 1-100, mostrar si es divisible entre 2
		
		Scanner tc= new Scanner(System.in);
		
		int contador1=0, contador2=0;
		for ( int i = 1; i<=100; i++) {
			System.out.println(i);
			if (i%2==0) {
				contador1=i;
				System.out.println( "Los numeros divisibles entre 2 son= "+ contador1);
			}
			}
		for ( int i = 1; i<=100; i++) {
			System.out.println(i);
			if (i%3==0) {
				contador2=i;
				System.out.println( "Los numeros divisibles entre 3 son= "+ contador2);
			}
			
		}
		}
		
	}

