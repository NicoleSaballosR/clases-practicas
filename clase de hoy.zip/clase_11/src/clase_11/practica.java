package clase_11;

import java.util.Scanner;

public class practica {

	public static void main(String[] args) {
		// Calcular el salario de un trabajador 
       Scanner tc= new Scanner(System.in);
       
       float sal_bas = 0, total_final=0;
       int horas=0, horas_extra;
       float inss=0;
       String nombre = null;
       String respuesta;
       
    for (int i = 1; i<=5; i++) {
         
       System.out.println("Ingrese su nombre");
       nombre= tc.nextLine();
       System.out.println("Ingrese su salario básico");
       sal_bas=tc.nextFloat();
       do {
       System.out.println("Usted realizo horas extra?");
       respuesta=tc.next();
       } while 
      
			 horas_extra= horas*365;
			 
       sal_bas= tc.nextFloat();
       System.out.println("Ingrese la cantidad de horas extras realizadas");
       horas= tc.nextInt();
       System.out.println("---------------------------------------------------------------------");
    
       inss= (float) (sal_bas*6.25/100);
       total_final= (sal_bas+horas_extra)-inss;
       
  System.out.printf("%-10s%-10s%-10s%-10s%-10s\n", "Nombre" , "Horas extras", "Salario basico", "Total recibido");
  System.out.printf("%-10s%-10s%-10s%-10s%-10s\n",  nombre,      horas_extra,  sal_bas,             total_final);
  
	System.out.println("----------------------------------------------------------------------");
		
    	   System.out.println("Ingrese la cantidad de horas extras realizadas");
           horas= tc.nextInt();
           System.out.println("---------------------------------------------------------------------");
        
           inss= (float) (sal_bas*6.25/100);
           total_final= sal_bas-inss;
           
           System.out.printf("%-10s%-10s%-10s%-10s%-10s\n", "Nombre" , "Salario basico", "Total recibido");
           System.out.printf("%-10s%-10s%-10s%-10s%-10s\n",  nombre,        sal_bas,             total_final);
           
           System.out.println("---------------------------------------------------------------------");
       
		
    }
	}
}
