package arreglo;

import java.util.Scanner;

public class sistermatico {

	public static void main(String[] args) {
		// producto punto 
		Scanner tc= new Scanner (System.in);
		
		int  a[], b[], n1 = 0 , n2 = 0, suma=0, z=0;
		int prod_punto = 0;
		int producto=prod_punto;
		a= new int[n1];
		b= new int [n2];
		double mod_A=0, mod_B=0;
	
		
		
		System.out.println("Determine el tamaño del arreglo 1");
		n1= tc.nextInt();
		System.out.println("Ingrese el tamaño del arreglo 2");
		n2= tc.nextInt();
		
		if (n1==n2)
			
		{
			for(int i = 0; i<a.length;i++) {
				System.out.println("digite los valores a evaluar"+(i+1));
				a[i]= tc.nextInt();
			
			
		}
			for (int p=0; p<b.length;p++) {
				System.out.println("digite los valores a evaluar"+ (p+1));
				b[p]= tc.nextInt();
			
				
				}
			int i=0;
			int p=0;
			producto += a[i]*b[p];
		    mod_A=	 Math.sqrt(prod_punto(a,a));
		    mod_B= Math.sqrt(prod_punto(b,b));
		    z = (int) (producto/ (mod_A* mod_B));
			
			}
		else {
			System.out.println("Reingrese el tamaño de los arreglos");
		}

		
		
	 
		
	
		
		
		}

	private static double prod_punto(int[] a, int[] a2) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
	}


