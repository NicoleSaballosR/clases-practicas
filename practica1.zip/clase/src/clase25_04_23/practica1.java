package clase25_04_23;

public class practica1 {

	public static void main(String[] args) {
		// realiza un programa que lea una cadena y la imprima desordenada y diga el tamaño de esa cadena
		

	}

}
