package Clases;

import java.util.Scanner;

public class principal {

	public static void main(String[] args) {
			
		Scanner tc= new Scanner(System.in);
		int a, b;
		
		operaciones op= new operaciones();
		System.out.println("ingrese el primer dato:");
		a=tc.nextInt();
		System.out.println("ingrese el segundo dato:");
		b=tc.nextInt();
		
		//op.Suma(a, b);
		
		System.out.println("el resultado es:"+ op.Resta(a, b));
		op.Saltos();
		op.Mostrar_Mensaje();
		
		System.out.println("el resultado de la suma es:"+ op.Suma(a, b));
	}

}
