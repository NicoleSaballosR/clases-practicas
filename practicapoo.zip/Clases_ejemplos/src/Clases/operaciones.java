package Clases;

public class operaciones {
	int num1;     //Atributos de la clase operaciones
	int num2;
	
	
	public operaciones() { //Constructor
		 
	}


	public operaciones(int num1, int num2) {
		this.num1 = num1;
		this.num2 = num2;
	}

	//Metodos setter and getter
	
	public int getNum1() {
		return num1;
	}


	public void setNum1(int num1) {
		this.num1 = num1;
	}


	public int getNum2() {
		return num2;
	}


	public void setNum2(int num2) {
		this.num2 = num2;
	}
	

	//Métodos u Operaciones propios 
	
	public static int Suma(int num1, int num2) {
		int suma;
		suma=num1+num2;
		return suma;
	}
	
	public static int Resta(int a, int b) {
		int resta;
		return resta= a-b;
	}
	
	
	public void Mostrar_Mensaje() {
		
		System.out.println("Saliendo...");
	}
	
	
	public void Saltos() {
		
		for(int i=0; i<=40; i++) {
			System.out.println(" ");
		}
		
	}
	
	
	
}
