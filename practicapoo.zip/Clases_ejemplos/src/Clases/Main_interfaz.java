package Clases;

import javax.swing.JOptionPane;

public class Main_interfaz {

	public static void main(String[] args) {
		
		int a, b;
		operaciones op = new operaciones();
		
		a=Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el primer dato"));
		b=Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el segundo dato"));
		
		JOptionPane.showMessageDialog(null, "el resultado de la suma: "+op.Suma(a, b));
		
		
		
		

	}

}
