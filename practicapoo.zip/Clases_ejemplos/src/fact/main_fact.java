package fact;

import java.util.Scanner;

public class main_fact {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		fact_Op fo= new fact_Op();
		int  n;
		
		System.out.println("Ingrese un numero a factor");
		n= tc.nextInt();
		
		
		System.out.println("el factorial de "+ n+" es: "+fo.factorialD(n));
		
		

	}

}
