package fact;

public class fact_Op {

	int num;

	public fact_Op() {
		// TODO Auto-generated constructor stub
	}

	public fact_Op(int  num) {
		this.num = num;
	}

	public double getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}
	

	
	public double factorialD(int n) {
		double f=1;
		
		for(int i=1; i<=n; i++) {
			f=f*i;
		}
		return f;
	}

	 
}
