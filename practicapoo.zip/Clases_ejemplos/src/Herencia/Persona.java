package Herencia;

public class Persona {
	private String nombre;
	private String apellido;
	private String nacionalidad;
	private int edad;
	

	
	//Constructor
	public Persona(String _nombre, String _apellido, String _nacionalidad, int _edad) {
		this.nombre = _nombre;
		this.apellido = _apellido;
		this.nacionalidad = _nacionalidad;
		this.edad = _edad;
	}
	
	//Se crean los metodos Set y Get
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getNacionalidad() {
		return nacionalidad;
	}
	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}

	
	
	
}
