package Herencia;

public final class teacher extends Persona {
	private String cedula;
	
	public String getCedula() {
		return cedula;
	}

	public void setCedula(String cedula) {
		this.cedula = cedula;
	}

	public teacher(String nombre, String apellido, String nacionalidad, int edad) {
		super(nombre, apellido, nacionalidad, edad);
		// TODO Auto-generated constructor stub
	}

	
	
}
