package Herencia;

import javax.swing.JOptionPane;

public final class Alumno extends Persona {

	public Alumno(String nombre, String apellido, String nacionalidad, int edad) {
		super(nombre, apellido, nacionalidad, edad);
		// TODO Auto-generated constructor stub
	}


	private String Matric;
	
		
	public String getMatric() {
		return Matric;
	}


	public void setMatric(String matric) {
		Matric = matric;
	}




	
//Metod propio de alumno
 
	
	public void MostrarDatos() {
		JOptionPane.showMessageDialog(null, "Alumno:"+"\n"+getNombre()+"\n"+getApellido()+"\n"+getNacionalidad()+"\n"+getEdad()+"\n"+getMatric());
	}

	public static int Suma(int n, int m) {
		int suma;
		suma=n+m;
		return suma;
	}
}
