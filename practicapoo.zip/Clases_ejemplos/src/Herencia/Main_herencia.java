package Herencia;

public class Main_herencia {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Alumno al= new Alumno("Juan", "Robles","CR",12);
		
		al.setMatric("123");
		al.MostrarDatos();

		
	}

}
