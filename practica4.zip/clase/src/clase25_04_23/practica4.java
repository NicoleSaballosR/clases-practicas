package clase25_04_23;

public class practica4 {

	public static void main(String[] args) {
		// realice unswhitch de caracteres +,-,/,* y de acuerdo a lo ingresado realice las la operaciòn
	}

}
