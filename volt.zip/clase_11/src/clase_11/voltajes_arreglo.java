package clase_11;

import java.util.Scanner;

public class voltajes_arreglo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner tc=new Scanner(System.in);
	   int n;
	int voltajes[], vol;
    int max=Integer.MAX_VALUE , min =Integer.MIN_VALUE, suma=0;
    double promedio=0;
        
      System.out.println("Ingrese la cantidad de voltajes que desee evaluar");
      n=tc.nextInt();
      voltajes=new int [n];
      
      for (int j=0; j<n; j++) {
    	  System.out.println("Ingrese los valores del voltaje");
    	 voltajes[j]=tc.nextInt();
    	 suma += voltajes[j];
      }
      
      
      
	 
	promedio= (double) suma/n;
	
     System.out.println("-------------------------------------------------------------------------");
     System.out.println("El voltajes minimo es = \n"+min);
     System.out.println("El voltajes maximo es= \n"+max);
     System.out.println("El promedio de voltajes es = \n"+promedio);
	}
    
}
