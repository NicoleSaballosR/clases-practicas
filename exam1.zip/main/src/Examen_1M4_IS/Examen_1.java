package Examen_1M4_IS;
import java.util.Scanner;
public class Examen_1 {

	public static void main(String[] args) {
		// login
       Scanner tc= new Scanner(System.in);
       
       int contador=0;
      String contraseña = "123";
       String user= "usuario1";
       String usuario, password;
       int opc;
       int a=100, b=150, c=40, compras = 0;
    
      
       contador= 0;
       do {
    	   System.out.println("Ingrese su usuario");
    	   usuario= tc.nextLine();
    		   System.out.println("Ingrese su contraseña");
    		   password= tc.nextLine();
		   
	    if (usuario==user && password== contraseña) {
	    	System.out.println("Bienvenido usuario que tramite desa realizar?");
	        do {
	     	    System.out.println("Ingrese una opción  \n 1-Realizar tramite \n 2-Imprimir factura \n 3-Salida  ");
	     	    opc= tc.nextInt();
	     	    
	     	   switch (opc) {
	     		   case 1:
	     			   System.out.println("Que desea comprar el dia de hoy?");
	     			   System.out.println("1-Pantalones a 150 \\n 2-camisas a 100 \\n 3-aretes a 40");
	     			  System.out.println("Cuantos articulos desea comprar");
	     			   int n= tc.nextInt();
	     			   for (int i=0; i<=n;i++) {
	     			   System.out.println("Opciones\na-Pantalones a 150\nb-camisas a 100\nc-aretes a 40 \n d- nada"+(i+1));
	     			 compras= tc.nextInt();
	     			   }
	     		   case 2: 
	     			   System.out.println("A ingresado a la opción factura su monto es de:");
				int total = 0;
				compras+= total;
				System.out.println("*************************************************************************");
				System.out.println("Factura");
				System.out.println("**************************************************************************");
                System.out.println("El total de su compra es; \n"+total);
	     		 
	   
	     	   } 
	     	  
	        
	        
	        }while (opc!=3);
	    } else {
	    	   System.out.println("Ingrese su usuario");
	    	   usuario= tc.nextLine();
	    		   System.out.println("Ingrese su contraseña");
	    		   password= tc.nextLine();
	    } 
    
	    
	   
	   
       } while (usuario!=user && password!= contraseña);
       contador++;
	}

}

	
