package clase26_04_23;

import java.util.Scanner;

public class practica2 {

	public static void main(String[] args) {
		//en un while muestra los numero del 1-100
		
		Scanner tc= new Scanner(System.in);
		
		int n=1;
		
		while (n<100) {
			n++;
			System.out.println(n);
		}
		
	

	}

}
