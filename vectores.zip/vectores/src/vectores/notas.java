package vectores;

import java.util.Scanner;

public class notas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Scanner tc= new Scanner(System.in);
 int cantidad_notas=5;
 
 int[] notas = new int [cantidad_notas];
 for( int i=0; i<cantidad_notas; i++) {
	 System.out.println("Las notas ingresadas deben ser de 0 a 10");
	 System.out.println("Ingrese la nota"+ (i+1)+ ":");
	 notas[i]= tc.nextInt();
 }
 
 System.out.println("Notas registradas");
 for (int nota:notas) {
 System.out.println(nota);
	}

 int notamin= notas[0];
 for (int i=1; i<cantidad_notas; i++) {
	 if (notas[i]<notamin) {
		 notamin= notas[i];
	 }
 }
 System.out.println("Nota más baja"+ notamin);
 
 int notamax= notas[0];
 for(int i=1; i<cantidad_notas; i++) {
	 if (notas[i]> notamax) {
		 notamax= notas[i];
	 }
 }
 
System.out.println("Notas más alta"+ notamax);

int sumanotas=0;
for(int nota:notas) {
	sumanotas +=nota;
}
double notamedia= (double)sumanotas/cantidad_notas;
System.out.println("La nota media es "+ notamedia);
}
}
