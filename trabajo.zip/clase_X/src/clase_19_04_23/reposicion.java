package clase_19_04_23;


import java.util.Scanner;

public class reposicion {

	public static void main(String[] args) {
		// notas
		 Scanner tc= new Scanner(System.in);
		 int n=4 ;
			float suma=0,promedio=0;
			//Recolección de Datos
			int notas[];
			
			try {	
				System.out.println("Ingrese la cantidad de notas");
				n= tc.nextInt();
				notas= new int [n];
				
				if (n!=4) {
					System.out.println("Porfavor ingrese otra vez la cantidad de notas a evaluar");
					System.out.println("Ingrese la cantidad de notas");
					n= tc.nextInt();
					notas= new int [n];
				}
			
			for (int i=0; i<=10; i++) {	
			
				do {
					System.out.println("----------------------------------------------------------------------------------------------");
					System.out.println("Ingrese la nota de matemática ");
					int  notamat = tc.nextInt();
					System.out.println("----------------------------------------------------------------------------------------------");
					System.out.println("Ingrese la nota de ingles ");
					int notasing=  tc.nextInt();
					System.out.println("----------------------------------------------------------------------------------------------");
					System.out.println("Ingrese la nota español ");
					int notasespa=  tc.nextInt();
					System.out.println("----------------------------------------------------------------------------------------------");
					System.out.println("Ingrese la nota de fisica ");
					int notasfis=  tc.nextInt();
					suma += notas[i];
					promedio= suma/n;
			} while (notas[i]<0);
				
				
			int notasespa=0;
			int notasfis=0;
			int notasing = 0;
			int notasmat=0;
			
			
		
			
			System.out.println("Su promedio es = \n "+promedio);
	        System.out.println("----------------------------------------------------------------------------------------------");
		}
		}catch ( java.util.InputMismatchException j) {
			System.out.println("Solo se permiten números ");
		}
			}

	}

		


